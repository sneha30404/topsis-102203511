# TOPSIS Assignment

Python implementation of the TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution) algorithm for multi-criteria decision-making.

## Installation
